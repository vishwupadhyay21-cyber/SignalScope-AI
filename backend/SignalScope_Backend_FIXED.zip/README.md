# SignalScope Backend (SIH 2026)
> **Problem Statement 2:** SignalScope – Telling Real From Synthetic in the Age of Generative Media.

Welcome to the backend of **SignalScope**! This repository hosts the FastAPI-based backend service that serves our AI vs Real image classification and explainability pipeline.

---

## 🎯 Implementation Roadmap Overview

### Phase 1: Environment & FastAPI API Skeleton
- Modular FastAPI project structure with versioned routing (`/api/v1`)
- Automated OpenAPI & Swagger documentation (`/docs`)
- Health check endpoint (`GET /api/v1/health`)
- Centralized configuration via `.env` and `pydantic-settings`
- Structured console logging and global error handlers

### Phase 2: Image Upload & In-Memory Validation
- Endpoint: `POST /api/v1/analyze` accepting `multipart/form-data`
- Strict format validation: **JPEG**, **PNG**, **WEBP**
- In-memory integrity verification with Pillow (rejects corrupt, broken, or disguised files)
- Configurable upload size limit (`MAX_IMAGE_SIZE_MB=10` via `.env`)
- Zero disk footprint (safe in-memory processing without saving to disk)
- Standard HTTP error codes (`400`, `413`, `415`)

### Phase 3: ML Model Integration Interface
- Extensible Machine Learning architecture under `app/ml/`
- `BaseDetector` abstract base class defining the contract for model loading and prediction
- `DummyDetector` returning realistic, deterministic test predictions for development
- Image preprocessor utility (`app/ml/preprocessor.py`) handling RGB conversion and 224x224 resizing
- Singleton factory (`app/ml/factory.py`) for clean, single-line swapping with trained PyTorch models
- Unique tracking ID (`analysis_id` UUID4) generated for every request

### Phase 4: Image Metadata / EXIF Analysis *(Current)*
- Dedicated metadata extraction service (`app/services/metadata_extractor.py`)
- Extracts forensic camera make, camera model, editing software, timestamp, format, and dimensions
- Safe degradation: if an image has no EXIF or corrupted metadata, returns clean `{"available": false}` without crashing
- Zero disk footprint: inspects in-memory `PIL.Image` directly without duplicate file decoding
- **Strict Forensic Principle:** Metadata is treated purely as investigative context. It **never** influences or overrides the model's AI/Real verdict. Missing or suspicious metadata is never treated as proof of AI generation.
- Complete execution flow:
  ```text
  Upload image → Validate image → Extract Metadata → Preprocess image → DummyDetector → Prediction → Structured JSON
  ```

> [!NOTE]
> **Important:** The current detector is a **DummyDetector** designed for backend interface development and testing. No real ML weights or PyTorch training are executed in this phase. When your teammate has finished training the PyTorch model, it can be plugged into `app/ml/factory.py` with zero changes to the API routes!


---

## 🚀 Beginner Quickstart Guide (Local Setup)

Follow these simple steps in your terminal (PowerShell on Windows or Bash on Linux/macOS):

### Step 1: Open Terminal in Project Directory
Make sure your terminal is inside the root folder:
```powershell
cd d:\SIH
```

---

### Step 2: Create a Virtual Environment
A virtual environment ensures project dependencies don't interfere with other Python projects on your machine.

**Option A (Using Python):**
```powershell
python -m venv .venv
```

**Option B (Using uv - ultra fast):**
```powershell
uv venv .venv --python 3.11
```

---

### Step 3: Activate the Virtual Environment
Activate the environment so your terminal uses the local virtual environment's Python:

- **On Windows (PowerShell):**
  ```powershell
  .\.venv\Scripts\Activate.ps1
  ```
  *(If you get a script execution policy error, run `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass` first)*

- **On Windows (Command Prompt `cmd`):**
  ```cmd
  .venv\Scripts\activate.bat
  ```

- **On Linux / macOS:**
  ```bash
  source .venv/bin/activate
  ```

Once activated, your terminal prompt will show `(.venv)`.

---

### Step 4: Install Dependencies
Install the required packages from `requirements.txt`:

```powershell
pip install -r requirements.txt
```
*(Or if using uv: `uv pip install -r requirements.txt`)*

---

### Step 5: Start the Backend Server
Run the Uvicorn development server with auto-reload:

```powershell
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```
*(Or if using uv directly: `uv run uvicorn app.main:app --reload --host 0.0.0.0 --port 8000`)*

You will see output similar to:
```text
INFO:     Uvicorn running on http://0.0.0.0:8000 (Press CTRL+C to quit)
INFO:     Started reloader process
INFO:     Started server process
2026-09-11 22:30:00 | INFO     | SignalScope Backend:lifespan:16 - Starting SignalScope Backend v0.1.0 [development]
2026-09-11 22:30:00 | INFO     | SignalScope Backend:lifespan:17 - API Docs available at: http://localhost:8000/docs
INFO:     Application startup complete.
```

---

## 🌐 API Testing Guide

### 1. Interactive Swagger Documentation (`/docs`)
Open this in your web browser:
👉 **[http://localhost:8000/docs](http://localhost:8000/docs)**

---

### 2. Testing `POST /api/v1/analyze` in Swagger UI (Step-by-Step)

1. Open **[http://localhost:8000/docs](http://localhost:8000/docs)** in your browser.
2. Locate the **Analysis** section and click on the green **POST /api/v1/analyze** bar.
3. Click the **"Try it out"** button in the top right of that section.
4. Under the **file** parameter, click the **"Choose File"** button and pick an image (`.jpg`, `.png`, or `.webp`).
5. Click the large blue **"Execute"** button.
6. Scroll down to view the **Server response**:
   - **Code**: `200 OK`
   - **Response Body (Image with EXIF metadata)**:
     ```json
     {
       "status": "success",
       "analysis_id": "93e8e7db-f807-4d23-9d9a-1ac92ad57972",
       "filename": "camera_shot.jpg",
       "verdict": {
         "label": "AI-generated",
         "confidence": 0.85
       },
       "probabilities": {
         "real": 0.15,
         "ai_generated": 0.85
       },
       "metadata": {
         "available": true,
         "image_format": "JPEG",
         "width": 1920,
         "height": 1080,
         "camera_make": "Canon",
         "camera_model": "EOS R5",
         "software": "Adobe Photoshop 2026",
         "datetime": "2026:09:11 21:15:00"
       }
     }
     ```
   - **Response Body (Image without EXIF metadata)**:
     ```json
     {
       "status": "success",
       "analysis_id": "d535f20e-0073-4bb3-b4ae-4083a7c39c10",
       "filename": "clean_render.png",
       "verdict": {
         "label": "AI-generated",
         "confidence": 0.85
       },
       "probabilities": {
         "real": 0.15,
         "ai_generated": 0.85
       },
       "metadata": {
         "available": false
       }
     }
     ```

#### Testing Error Scenarios in Swagger UI:
- **Corrupted / Fake Image:** Rename a `.txt` file to `.jpg` and upload it. Observe response: `400 Bad Request` (`"Uploaded file is corrupted or not a valid image."`).
- **Unsupported Format:** Upload a `.gif`, `.bmp`, or `.pdf`. Observe response: `415 Unsupported Media Type` (`"Unsupported image format 'GIF'. Allowed formats: JPEG, PNG, WEBP."`).
- **No File Provided:** Click "Execute" without choosing a file. Observe response: `400 Bad Request` (`"No file provided. Please upload an image file."`).

---

### 3. Testing via Terminal

#### A. Health Check
```powershell
Invoke-RestMethod -Uri "http://localhost:8000/api/v1/health"
```
*Expected Response:*
```json
{"status": "healthy"}
```

#### B. Uploading an Image via PowerShell
```powershell
$form = @{
    file = Get-Item -Path "path\to\your\image.jpg"
}
Invoke-RestMethod -Uri "http://localhost:8000/api/v1/analyze" -Method Post -Form $form
```

#### C. Uploading an Image via curl
```bash
curl -X POST "http://localhost:8000/api/v1/analyze" \
     -H "accept: application/json" \
     -F "file=@path/to/your/image.jpg"
```

---

### 4. Running Automated Tests

To run the complete test suite across all phases:
```powershell
uv run python -m unittest discover tests
```

---

## 📁 Project Structure (Phase 4)

```text
d:\SIH\
├── app/
│   ├── __init__.py               # Makes 'app' a Python package
│   ├── main.py                   # FastAPI app initialization, middleware, error handlers
│   ├── api/
│   │   ├── __init__.py
│   │   └── v1/
│   │       ├── __init__.py
│   │       ├── router.py         # Aggregates v1 endpoints (health, analyze)
│   │       └── endpoints/
│   │           ├── __init__.py
│   │           ├── health.py     # Health check endpoint (GET /api/v1/health)
│   │           └── analyze.py    # Upload, validation, metadata & detection (POST /api/v1/analyze)
│   ├── core/
│   │   ├── __init__.py
│   │   ├── config.py             # App configuration, size limits & allowed formats
│   │   └── logger.py             # Structured logging configuration
│   ├── ml/
│   │   ├── __init__.py           # ML module exports
│   │   ├── base.py               # BaseDetector abstract base class
│   │   ├── dummy.py              # DummyDetector implementation for dev/testing
│   │   ├── factory.py            # Singleton provider for active detector model
│   │   └── preprocessor.py       # Standard CV image preprocessing (224x224 RGB)
│   ├── schemas/
│   │   ├── __init__.py
│   │   └── analyze.py            # Pydantic schemas (Verdict, Probabilities, ImageMetadata, AnalysisResponse)
│   └── services/
│       ├── __init__.py
│       ├── image_validator.py    # In-memory image inspection & Pillow validation
│       └── metadata_extractor.py # Forensic metadata & EXIF extraction
├── tests/
│   ├── __init__.py
│   └── test_analyze.py           # Automated unit tests covering all 4 phases (16 tests)
├── .env                          # Local environment configuration (MAX_IMAGE_SIZE_MB=10)
├── .env.example                  # Template for environment configuration
├── .gitignore                    # Git exclusions (.venv, __pycache__, etc.)
├── requirements.txt              # Project dependencies
└── README.md                     # Beginner documentation & testing guide
```


