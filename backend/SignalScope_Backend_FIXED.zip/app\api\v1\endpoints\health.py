"""Health check endpoint."""

from fastapi import APIRouter

router = APIRouter()


@router.get(
    "/health",
    summary="Health Check",
    description="Returns the operational status of the API server.",
    response_model=dict,
)
async def health_check():
    """Returns 'healthy' status indicating the server is running."""
    return {"status": "healthy"}
