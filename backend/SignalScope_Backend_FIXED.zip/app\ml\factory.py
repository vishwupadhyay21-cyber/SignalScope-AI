"""Detector Factory and dependency provider.

Provides a singleton instance of the detector to avoid reloading model
weights on every HTTP request.
"""

from app.ml.base import BaseDetector
from app.ml.dummy import DummyDetector

# Global cached detector instance (Singleton)
_detector_instance: BaseDetector = None


def get_detector() -> BaseDetector:
    """Returns the active detector instance.

    To replace the DummyDetector with a trained PyTorch model in the future:
    Simply instantiate the PyTorch detector here:
        _detector_instance = PyTorchDetector(weights_path="models/weights.pth")
    No changes to the API routes will be required!
    """
    global _detector_instance
    if _detector_instance is None:
        _detector_instance = DummyDetector()
    return _detector_instance
